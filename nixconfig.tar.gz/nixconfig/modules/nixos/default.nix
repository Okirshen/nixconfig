{
  pkgs,
}:

{
  networking.networkmanager.enable = true;
  time.timeZone = "Asia/Jerusalem";

  # Set Dash as login shell
  environment.binsh = "${pkgs.dash}/bin/dash";
  environment.systemPackages = [ pkgs.dash ];

}
