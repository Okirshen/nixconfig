{
  pkgs,
}:
{
  programs = {
    direnv = {
      enable = true;
      nix-direnv.enable = true;
      enableFishIntegration = true;
    };
    firefox.enable = true;
    zoxide = {
      enable = true;
      enableFishIntegration = true;
    };
  };

  environment.sessionVariables.NIXOS_OZONE_WL = "1";

  services = {
    displayManager.ly = {
      enable = true;
      settings = {
        animation = "doom";
        bigclock = "en";
        clock = "%H:%M:%S %d/%m";
      };
    };
    desktopManager.plasma6.enable = true;
    printing.enable = true;
    avahi = {
      enable = true;
      nssmdns4 = true;
      openFirewall = true;
    };
    gnome.gnome-keyring.enable = true;
    pipewire = {
      enable = true;
      alsa.enable = true;
      alsa.support32Bit = true;
      pulse.enable = true;
      jack.enable = true;
    };
    blueman.enable = true;
  };

  security = {
    rtkit.enable = true;
  };

  virtualisation = {
    libvirtd.enable = true;
    docker.enable = true;
  };

  hardware = {
    bluetooth.enable = true;
  };

  fonts.packages = with pkgs; [
    corefonts
    noto-fonts
    nerd-fonts.fira-code
    twemoji-color-font
  ];

  environment.systemPackages = with pkgs; [
    virtualenv
    tokei
    wl-clipboard
    grim
    slurp
    tesseract
    imagemagick
    pavucontrol
    obsidian
    spotify
    aseprite-unfree
    godot
    stremio
    prismlauncher
    pfetch
    obs-studio
    mpv
    jellyfin-rpc
    jellyfin-media-player
    python3
    bacon
    ncspot
    helvum
    qbittorrent
    protonup-qt
    chafa
    lazygit
    kdenlive
    prusa-slicer
    protonvpn-gui
    zoom-us
    onlyoffice-bin_latest
    logiops
    ffmpeg
    protontricks
    discord-canary
    mangohud

    lua-language-server
    rust-analyzer
    fish-lsp
    bash-language-server
    taplo-lsp
  ];
}
