{
  pkgs,
}:

{
  networking.networkmanager.enable = true;
  time.timeZone = "Asia/Jerusalem";

  # Set Dash as login shell
  environment.binsh = "${pkgs.dash}/bin/dash";

  # Disable mouse acceleration
  services.libinput = {
    enable = true;
    mouse.accelProfile = "flat";
    touchpad.accelProfile = "flat";
  };

  hardware.enableRedistributableFirmware = true;

  environment.systemPackages = with pkgs; [
    dash
    git
    wget
    vim
    bottom
    tree
    eza
    bat
    fd
    ripgrep
    fzf
    nixd
    nixfmt-rfc-style
  ];
}
